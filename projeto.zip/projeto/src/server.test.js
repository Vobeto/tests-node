// server.test.js
const request = require('supertest');
const { startServer, stopServer } = require('./server'); // Importando as funções para iniciar e parar o servidor

describe('Testando o servidor HTTP', () => {
  beforeAll(async () => {
    // Inicia o servidor antes de rodar os testes
    await startServer();
  });

  afterAll(async () => {
    // Fecha o servidor após rodar os testes
    await stopServer();
  });

  it('deve responder com status 200 e "Hello, World!"', async () => {
    const response = await request('http://127.0.0.1:3000') // Conecta diretamente à URL
      .get('/')
      .expect('Content-Type', /text\/plain/)
      .expect(200);
      
    // Verifica se a resposta contém o texto "Hello, World!"
    expect(response.text).toBe('Hello, World!\n');
  });
});
